
export var GLOBAL = {
    url: 'http://127.0.0.1:4201/api/',
}